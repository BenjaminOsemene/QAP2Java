// This class demonstrates the usage of the CreditCard class
public class CreditCardDemo {
    public static void main(String[] args) {
        // Address object updated with the provided address information
        Address address = new Address("237J Harvey Hall", "Menomonie", "WI", "54751");

        // Person object updated with the provided name and address
        Person owner = new Person("Diane", "Christie", address);

        // CreditCard object created with the owner and a credit limit of $1000.00
        CreditCard card = new CreditCard(owner, new Money(1000.0));

        // Outputting  the owner's personal information, initial balance, and credit limit
        System.out.println(card.getPersonals());
        System.out.println("Balance: " + card.getBalance());
        System.out.println("Credit Limit: " + card.getCreditLimit());

        // Charging $200.00 to the credit card
        System.out.println("\nAttempt to charge $200.00");
        card.charge(new Money(200.0));

        // Charging $10.02 to the credit card
        System.out.println("\nAttempt to charge $10.02");
        card.charge(new Money(10.02));

        // Making a payment of $25.00 to the credit card
        System.out.println("\nAttempt to pay $25.00");
        card.payment(new Money(25.0));

        // Charging $990.00 to the credit card (exceeding the credit limit)
        System.out.println("\nAttempt to charge $990.00");
        card.charge(new Money(990.0));
    }
}
 
  
    
