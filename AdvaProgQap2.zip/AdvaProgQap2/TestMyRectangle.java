public class TestMyRectangle {
    public static void main(String[] args) {
        // Testing MyRectangle using coordinates
        MyRectangle rect1 = new MyRectangle(1, 2, 4, 6);
        System.out.println("Rectangle 1: " + rect1);
        System.out.println("Area: " + rect1.getArea());
        System.out.println("Perimeter: " + rect1.getPerimeter());
        System.out.println();

        // Testing MyRectangle using MyPoint objects
        MyPoint topLeft = new MyPoint(2, 3);
        MyPoint bottomRight = new MyPoint(6, 7);
        MyRectangle rect2 = new MyRectangle(topLeft, bottomRight);
        System.out.println("Rectangle 2: " + rect2);
        System.out.println("Area: " + rect2.getArea());
        System.out.println("Perimeter: " + rect2.getPerimeter());
        System.out.println();

        // Testing by adjusting the rectangle
        rect2.setTopLeft(new MyPoint(0, 0));
        rect2.setBottomRight(new MyPoint(5, 5));
        System.out.println("Modified Rectangle 2: " + rect2);
        System.out.println("Area: " + rect2.getArea());
        System.out.println("Perimeter: " + rect2.getPerimeter());
    }
}