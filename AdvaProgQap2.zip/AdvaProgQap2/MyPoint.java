public class MyPoint { // This defines MyPoint class
    //Here two instance variable are defined
    private int x;
    private int y;

    //Creating a parameterized constructor
    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }
 
    // Methods like getX() and getY()
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    //Adding the distance() method to MyPoint class
    public double distance(MyPoint other) {
        int dx = x - other.x;
        int dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
    

    