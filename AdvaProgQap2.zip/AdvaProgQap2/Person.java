// This is a person class with first name, last name, and home address as instances
public class Person {
    private String lastName; 
    private String firstName; 
    private Address home; 

    // Constructor to initialize a Person object with first name, last name, and home address
    public Person(String firstName, String lastName, Address home) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.home = home;
    }

    // This method returns a string representation of the person in the format "lastName, firstName, address"
    public String toString() {
        return lastName + ", " + firstName + ", " + home.toString();
    }

}