//Imported the required library
import java.util.Arrays;

//Define MyLine class with two instance variables
public class MyLine {
    private MyPoint begin;
    private MyPoint end;

    //Defined contructor with coordinates 
    public MyLine(int x1, int y1, int x2, int y2) {
        begin = new MyPoint(x1, y1);
        end = new MyPoint(x2, y2);
    }

    //Define constructor with MyPoint objects
    public MyLine(MyPoint begin, MyPoint end) {
        this.begin = begin;
        this.end = end;
    }

    //Adding getter for begin
    public MyPoint getBegin() {
        return begin;
    }

    //Adding getter for end
    public MyPoint getEnd() {
        return end;
    }

    //Adding setter for begin
    public void setBegin(MyPoint begin) {
        this.begin = begin;
    }

    //Adding setter for end
    public void setEnd(MyPoint end) {
        this.end = end;
    }

    //Getter for begin-X coordinate
    public int getBeginX() {
        return begin.getX();
    }

    //Setter for begin-X coordinate
    public void setBeginX(int x) {
        begin = new MyPoint(x, begin.getY());
    }

    //Getter for Begin-Y coordinate
    public int getBeginY() {
        return begin.getY();
    }

    //Setter for begin-Y coordinate
    public void setBeginY(int y) {
        begin = new MyPoint(begin.getX(), y);
    }

    //Getter for end-X coordinate
    public int getEndX() {
        return end.getX();
    }

    // Setter for End-X coordinate
    public void setEndX(int x) {
        end = new MyPoint(x, end.getY());
    }

    //Geter for end-Y coordinate
    public int getEndY() {
        return end.getY();
    }

    //Setter for end-Y coordinate
    public void setEndY(int y) {
        end = new MyPoint(end.getX(), y);
    }

    //Getter fior begin coordinates
    public String getBeginXY() {
        return Arrays.toString(new int[]{begin.getX(), begin.getY()});
    }

    //Setter for begin coordinates
    public void setBeginXY(int x, int y) {
        begin = new MyPoint(x, y);
    }

    //Getter for end coordinates
    public String getEndXY() {
        return Arrays.toString(new int[]{end.getX(), end.getY()});
    }

    //Setter for end coordinates
    public void setEndXY(int x, int y) {
        end = new MyPoint(x, y);
    }

    //Lenght method-calculating the lenght of the line
    public double getLength() {
        return begin.distance(end);
    }

    //Gradient method-calculating the gradient of the line
    public double getGradient() {
        int xDiff = end.getX() - begin.getX();
        int yDiff = end.getY() - begin.getY();
        return Math.atan2(yDiff, xDiff);
    }

    //toString method to represent the line as a string
    public String toString() {
        return "MyLine[begin=" + begin + ", end=" + end + "]";
    }
}