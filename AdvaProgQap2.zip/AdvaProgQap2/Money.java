// This is a class of money amount with dollars and cents
public class Money {
    private long dollars; 
    private long cents; 

    // Constructor to initialize a Money object from a double value
    public Money(double amount) {
        this.dollars = (long) amount;
        this.cents = (long) ((amount - this.dollars) * 100);
    }

    // Copy constructor to initialize a Money object from another Money object
    public Money(Money otherObject) {
        this.dollars = otherObject.dollars;
        this.cents = otherObject.cents;
    }

    // This method adds the specified amount to the current amount and returns the result
    public Money add(Money otherAmount) {
        long totalCents = this.cents + otherAmount.cents;
        long newDollars = this.dollars + otherAmount.dollars + totalCents / 100;
        long newCents = totalCents % 100;
        return new Money(newDollars + (double) newCents / 100);
    }

    // This method subtracts the specified amount from the current amount and returns the result
    public Money subtract(Money otherAmount) {
        long totalCents = this.cents - otherAmount.cents;
        long newDollars = this.dollars - otherAmount.dollars + (totalCents < 0 ? -1 : 0);
        long newCents = totalCents < 0 ? 100 + totalCents : totalCents;
        return new Money(newDollars + (double) newCents / 100);
    }

    // Compares the current amount with the specified amount
    // Returns -1 if the current amount is less than the specified amount
    // Returns 1 if the current amount is greater than the specified amount
    // Returns 0 if the amounts are equal
    public int compareTo(Money otherObject) {
        if (this.dollars < otherObject.dollars) {
            return -1;
        } else if (this.dollars > otherObject.dollars) {
            return 1;
        } else {
            return Long.compare(this.cents, otherObject.cents);
        }
    }

    // This checks if the current amount is equal to the specified amount
    public boolean equals(Money otherObject) {
        return this.dollars == otherObject.dollars && this.cents == otherObject.cents;
    }

    // Then provides string representation of the amount in the format "$dollars.cents"
    public String toString() {
        return "$" + this.dollars + "." + String.format("%02d", this.cents);
    }
}

 