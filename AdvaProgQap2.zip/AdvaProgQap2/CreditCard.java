// This is a  credit card class with a balance, credit limit, and owner.
public class CreditCard {
    private Money balance; 
    private Money creditLimit; 
    private Person owner; 

    // Constructor to initialize a new CreditCard object
    public CreditCard(Person newCardHolder, Money limit) {
        this.owner = newCardHolder;
        this.creditLimit = limit;
        this.balance = new Money(0.0); 
    }

    // This method provides the current balance of the credit card
    public Money getBalance() {
        return new Money(balance);
    }

    // This method provides the credit limit of the credit card
    public Money getCreditLimit() {
        return new Money(creditLimit);
    }

    // This method provides personal information of the credit card owner
    public String getPersonals() {
        return owner.toString();
    }

    // Charges the specified amount to the credit card
    // If the new balance exceeds the credit limit, the charge is rejected
    public void charge(Money amount) {
        Money newBalance = balance.add(amount);
        if (newBalance.compareTo(creditLimit) <= 0) {
            balance = newBalance;
            System.out.println("Charge: " + amount);
            System.out.println("Balance: " + balance);
        } else {
            System.out.println("Charge amount exceeded credit limit.");
        }
    }

    // Makes a payment to the credit card
    public void payment(Money amount) {
        balance = balance.subtract(amount);
        System.out.println("Payment: " + amount);
        System.out.println("Balance: " + balance);
    }
}




    




