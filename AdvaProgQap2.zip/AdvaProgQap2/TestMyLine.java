
 //This tests MyLine class using three scenarios
 
public class TestMyLine {
    public static void main(String[] args) {
        // This test MyLine object using coordinates
        MyLine line1 = new MyLine(1, 2, 3, 4);
        System.out.println("Line 1: " + line1);
        System.out.println("Length of Line 1: " + line1.getLength());
        System.out.println("Gradient of Line 1: " + line1.getGradient());

        // This test MyLine object using MyPoint objects
        MyPoint begin = new MyPoint(5, 6);
        MyPoint end = new MyPoint(7, 8);
        MyLine line2 = new MyLine(begin, end);
        System.out.println("\nLine 2: " + line2);
        System.out.println("Length of Line 2: " + line2.getLength());
        System.out.println("Gradient of Line 2: " + line2.getGradient());

        // This test MyLine by adjusting the beginning and ending points of Line 2
        line2.setBeginXY(9, 10);
        line2.setEndXY(11, 12);
        System.out.println("\nModified Line 2: " + line2);
        System.out.println("Length of Modified Line 2: " + line2.getLength());
        System.out.println("Gradient of Modified Line 2: " + line2.getGradient());
    }
}
    

